package com.example.lab13

import android.app.Service
import android.content.Intent
import android.os.IBinder
import kotlinx.coroutines.* // 1. 引入協程庫

class MyService : Service() {

    // 2. 定義協程作用域 (在主執行緒執行，適合處理廣播)
    private val scope = CoroutineScope(Dispatchers.Main)

    // 3. 用來管理當前的倒數任務 (可被取消)
    private var job: Job? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // 解析 Intent，若為 null 則給空字串
        val channel = intent?.getStringExtra("channel") ?: ""

        // --- 第一步：立即發送歡迎廣播 ---
        sendBroadcast(channel, when(channel) {
            "music" -> "歡迎來到音樂頻道"
            "new"   -> "歡迎來到新聞頻道"
            "sport" -> "歡迎來到體育頻道"
            else    -> "頻道錯誤"
        })

        // --- 第二步：處理倒數任務 ---

        // 如果之前有還沒跑完的倒數 (例如使用者快速連續按按鈕)，先取消它
        job?.cancel()

        // 啟動新的協程任務
        job = scope.launch {
            // 使用 delay 取代 Thread.sleep (非阻塞式等待)
            delay(3000)

            // 時間到，發送第二則廣播
            sendBroadcast(channel, when(channel) {
                "music" -> "即將播放本月TOP10音樂"
                "new"   -> "即將為您提供獨家新聞"
                "sport" -> "即將播報本週NBA賽事"
                else    -> "頻道錯誤"
            })
        }

        return START_STICKY
    }

    override fun onBind(intent: Intent): IBinder? = null

    // 4. 當 Service 被銷毀時，確保所有協程都被取消，避免記憶體洩漏
    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
    }

    // 輔助函式：發送廣播
    private fun sendBroadcast(channel: String, msg: String) {
        val intent = Intent(channel).apply {
            putExtra("msg", msg)
            // 建議加上這行，限制廣播只發送給自己的 App (安全性較高)
            setPackage(packageName)
        }
        sendBroadcast(intent)
    }
}