package com.example.lab13

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
// 記得引入 ViewBinding 的類別 (需在 build.gradle 開啟 viewBinding)
import com.example.lab13.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    // 1. 使用 View Binding
    private lateinit var binding: ActivityMainBinding

    // 用來記錄目前是否已經註冊廣播，避免重複註冊或解除註冊時崩潰
    private var isRegistered = false

    // 建立 BroadcastReceiver 物件
    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            // 接收廣播後，解析 Intent 取得字串訊息
            // 使用 binding 直接操作 UI，不需要再 findViewById
            intent.extras?.getString("msg")?.let { msg ->
                binding.tvMsg.text = msg
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // 初始化 View Binding
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // 處理視窗邊緣
        ViewCompat.setOnApplyWindowInsetsListener(binding.main) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // 2. 設定按鈕監聽器，直接呼叫切換頻道的函式
        binding.btnMusic.setOnClickListener { switchChannel("music") }
        binding.btnNew.setOnClickListener { switchChannel("new") }
        binding.btnSport.setOnClickListener { switchChannel("sport") }
    }

    override fun onDestroy() {
        super.onDestroy()
        // 3. 只有在已經註冊的情況下才解除，避免閃退
        if (isRegistered) {
            unregisterReceiver(receiver)
            isRegistered = false
        }
    }

    private fun switchChannel(channel: String) {
        // 如果之前已經註冊過，先解除註冊，避免同時監聽多個頻道或重複註冊
        if (isRegistered) {
            unregisterReceiver(receiver)
            isRegistered = false
        }

        // 建立 IntentFilter 物件來指定接收的頻道
        val intentFilter = IntentFilter(channel)

        // 註冊廣播接收器 (Android 13+ 適配)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            // 如果 Service 屬於同一個 App，建議改用 RECEIVER_NOT_EXPORTED 會更安全
            // 這裡維持原本邏輯使用 EXPORTED，若有報錯可改為 RECEIVER_NOT_EXPORTED
            registerReceiver(receiver, intentFilter, RECEIVER_EXPORTED)
        } else {
            registerReceiver(receiver, intentFilter)
        }

        // 標記為已註冊
        isRegistered = true

        // 建立 Intent 並啟動 Service
        val i = Intent(this, MyService::class.java).apply {
            putExtra("channel", channel)
        }
        startService(i)
    }
}